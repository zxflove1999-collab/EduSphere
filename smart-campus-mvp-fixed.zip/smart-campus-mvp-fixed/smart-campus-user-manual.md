# 智能校园系统使用手册

## 一、用户使用手册（零基础版）

### 登录与注册

**示例账号：**
- 教师：t1@example.com / 123456
- 学生：s1@example.com / 123456

#### A. 直接登录
1. 打开 http://localhost:5173
2. 输入账号密码登录

#### B. 注册新账号
1. 打开 http://localhost:8000/docs
2. 找到 `POST /auth/register`
3. 填写：
   - name：姓名
   - email：邮箱
   - password：密码
   - role：TEACHER 或 STUDENT
4. 提交后即可登录

---

## 1. 教学系统

### 1.1 课程与课表
**教师**
1. 顶部导航选择“课程”
2. 点击“创建课程”
3. 创建后可看到课程 ID

**学生**
1. 顶部导航选择“课程”
2. 在“加入课程”中输入课程 ID
3. 点击“查看课表”即可看到完整课表

### 1.2 资源上传与下载
**教师**：上传 PPT、PDF 等资源  
**学生**：查看课程资源并下载

### 1.3 作业与成绩（AI 辅助评分）
**教师**
1. “发布作业”
2. 设置得分点（rubric）

**学生**
1. 输入作业 ID 提交作业
2. 系统自动评分并返回得分与建议
3. 可查看历史成绩

### 1.4 课堂考勤
**教师**：创建签到（设置位置、时间）  
**学生**：输入签到 ID → 获取定位 → 签到成功（人脸验证为示例通过）

---

## 2. 资源管理

### 2.1 空闲教室查询与预约
选择时间 → 查询空闲教室 → 填房间 ID → 预约。

### 2.2 图书借阅与评价
**学生**
1. 加载图书列表
2. 借阅图书（记录借阅 ID）
3. 归还时填写评分与评价（必须填写）
4. 系统自动生成图书标签，如“推荐”“可跳过”等。

---

## 3. 校园生活

### 3.1 宿舍分配
填写个人偏好（作息、整洁、噪音） → 一键分配 → 查看宿舍。

### 3.2 论坛
发帖、评论，支持文字、图片、视频。

---

## 4. 系统运维

- 启动：`docker compose up --build`
- 停止：`Ctrl + C` 或 `docker compose down`
- 后端文档：`http://localhost:8000/docs`
- 数据卷：`campus_data`

---

## 二、接口速查表

### 1) Auth
- POST `/auth/register`
- POST `/auth/login`
- GET `/users/me`

### 2) 课程
- POST `/courses`
- POST `/courses/{id}/join`
- GET `/courses/my`

### 3) 作业
- POST `/assignments`
- POST `/assignments/{id}/submit`
- GET `/assignments/grades/my`

### 4) 资源
- POST `/resources/upload`
- GET `/resources/list`

### 5) 考勤
- POST `/attendance`
- POST `/attendance/{id}/sign`
- GET `/attendance/my`

### 6) 图书馆
- GET `/library/books`
- POST `/library/borrow`
- POST `/library/return`

### 7) 宿舍
- POST `/dorm/preferences`
- POST `/dorm/assign`
- GET `/dorm/me`

### 8) 论坛
- POST `/forum/posts`
- GET `/forum/posts`
- POST `/forum/posts/{id}/comments`

---

## 三、UI 优化指南

### 路线A：Ant Design

1. 在 `package.json` 添加：
   ```json
   "antd": "^5.18.0",
   "@ant-design/icons": "^5.0.1"
   ```
2. 在 `main.jsx` 引入样式：
   ```js
   import "antd/dist/reset.css";
   ```
3. 使用 `Form`, `Input`, `Layout`, `Menu` 等组件美化页面。

### 路线B：Tailwind

1. 安装：
   ```bash
   npm i -D tailwindcss postcss autoprefixer
   npx tailwindcss init -p
   ```
2. 在 `index.css` 加入：
   ```css
   @tailwind base;
   @tailwind components;
   @tailwind utilities;
   ```
3. 用类名快速布局：`bg-gray-50 p-6 rounded-lg shadow`

---

## 四、系统亮点

- 作业 Rubric 打点评分（教师可控）
- 图书评价自动生成标签
- 地理围栏签到
- 容器化一键运行
- 支持 AI 评阅与学习建议
