import math, os
from typing import List, Dict

def haversine(lat1, lon1, lat2, lon2):
    R = 6371000.0
    from math import radians, sin, cos, asin, sqrt
    phi1, phi2 = radians(lat1), radians(lat2)
    dphi = radians(lat2 - lat1)
    dlambda = radians(lon2 - lon1)
    a = sin(dphi/2)**2 + cos(phi1)*cos(phi2)*sin(dlambda/2)**2
    return 2 * R * asin(sqrt(a))

TAGS = {"值得推荐": ["推荐","很好看","受益","喜欢","精彩"],
        "可跳过": ["没用","水","浪费","无聊","不用看"],
        "入门": ["基础","入门","新手"]}

def aggregate_tags(reviews: List[str]) -> Dict[str, int]:
    cnt = {}
    for text in reviews:
        for tag, words in TAGS.items():
            if any(w in text for w in words):
                cnt[tag] = cnt.get(tag, 0) + 1
    return cnt
