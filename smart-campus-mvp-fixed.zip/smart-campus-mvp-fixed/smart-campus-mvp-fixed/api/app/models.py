from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: str
    role: str  # 'STUDENT' | 'TEACHER' | 'ADMIN'
    password_hash: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Course(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    code: str
    teacher_id: int
    term: str
    schedule_json: str = "{}"
    capacity: int = 100

class Enrollment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    course_id: int
    student_id: int
    status: str = "ENROLLED"

class Assignment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    course_id: int
    title: str
    type: str = "SUBJ"
    start_at: datetime
    due_at: datetime
    rubric_json: str

class Submission(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    assignment_id: int
    student_id: int
    status: str = "SUBMITTED"
    text_content: Optional[str] = None
    files_json: Optional[str] = None
    ai_feedback_json: Optional[str] = None

class Grade(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    course_id: int
    student_id: int
    assignment_id: Optional[int] = None
    score: float
    total: float = 100.0
    details_json: Optional[str] = None

class Resource(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    course_id: int
    title: str
    type: str
    file_path: str
    size: int
    uploader_id: int
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Attendance(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    course_id: int
    start_at: datetime
    end_at: datetime
    lat: float
    lng: float
    radius_m: int = 80
    face_threshold: float = 0.35

class AttendanceLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    attendance_id: int
    student_id: int
    face_score: float = 0.0
    lat: float
    lng: float
    ts: datetime = Field(default_factory=datetime.utcnow)
    status: str

class Room(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    building: str
    room_no: str
    capacity: int
    type: str = "CLASS"

class RoomBooking(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    room_id: int
    user_id: int
    start_at: datetime
    end_at: datetime
    status: str = "CONFIRMED"

class Book(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    isbn: str
    title: str
    author: str
    tags: Optional[str] = None
    copies_total: int = 1
    copies_available: int = 1

class Loan(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    book_id: int
    user_id: int
    borrowed_at: datetime = Field(default_factory=datetime.utcnow)
    due_at: datetime
    returned_at: Optional[datetime] = None

class BookReview(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    book_id: int
    user_id: int
    rating: int
    text: str
    returned_at: datetime = Field(default_factory=datetime.utcnow)

class BookTagAgg(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    book_id: int
    tag: str
    weight: int = 0

class DormPreference(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int
    sleep: int = 1
    clean: int = 1
    noise: int = 1

class DormRoom(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    building: str
    room_no: str
    capacity: int = 4

class DormAssignment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    room_id: int
    user_id: int
    assigned_at: datetime = Field(default_factory=datetime.utcnow)

class ForumPost(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int
    title: str
    content: str
    media_json: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ForumComment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    post_id: int
    user_id: int
    content: str
    parent_id: Optional[int] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
