from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    secret_key: str = os.getenv("SECRET_KEY", "dev-secret-key")
    access_token_expire_minutes: int = 60 * 24
    db_url: str = "sqlite:///data/db.sqlite3"
    enable_face: int = int(os.getenv("ENABLE_FACE", "0"))

    admin_teacher_email: str = os.getenv("ADMIN_TEACHER_EMAIL", "t1@example.com")
    admin_teacher_password: str = os.getenv("ADMIN_TEACHER_PASSWORD", "123456")
    demo_student_email: str = os.getenv("DEMO_STUDENT_EMAIL", "s1@example.com")
    demo_student_password: str = os.getenv("DEMO_STUDENT_PASSWORD", "123456")

settings = Settings()
