import json, re
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Form
from sqlmodel import Session, select
from rapidfuzz import fuzz
from ..db import get_session
from ..auth import get_current_user
from ..models import Assignment, Submission, Course, Grade

router = APIRouter()

@router.post("")
def create_assignment(course_id: int = Form(...), title: str = Form(...), type: str = Form("SUBJ"),
                      start_at: str = Form(None), due_at: str = Form(None), rubric_json: str = Form("[]"),
                      session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role != "TEACHER":
        raise HTTPException(403, "Only teacher")
    if not session.get(Course, course_id):
        raise HTTPException(404, "Course not found")
    a = Assignment(course_id=course_id, title=title, type=type,
                   start_at=datetime.fromisoformat(start_at) if start_at else datetime.utcnow(),
                   due_at=datetime.fromisoformat(due_at) if due_at else datetime.utcnow(),
                   rubric_json=rubric_json)
    session.add(a); session.commit(); session.refresh(a)
    return a

@router.post("/{assignment_id}/submit")
def submit_assignment(assignment_id: int, text_content: str = Form(""),
                      session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role != "STUDENT":
        raise HTTPException(403, "Only student")
    a = session.get(Assignment, assignment_id)
    if not a: raise HTTPException(404, "Assignment not found")
    sub = Submission(assignment_id=assignment_id, student_id=user.id, text_content=text_content, status="SUBMITTED")
    # rule-based scoring
    try:
        rubric = json.loads(a.rubric_json or "[]")
    except Exception:
        rubric = []
    score, details = 0.0, []
    txt = (text_content or "").lower()
    for item in rubric:
        weight = float(item.get("weight", 0))
        got = False
        for pat in item.get("match", []):
            p = pat.lower()
            if p.startswith("re:"):
                if re.search(p[3:], txt): got = True
            else:
                if fuzz.partial_ratio(p, txt) >= 85: got = True
        if got:
            score += weight
        details.append({"key": item.get("key"), "ok": got, "delta": weight if got else 0})
    total = sum(float(i.get("weight", 0)) for i in rubric) or 100.0
    g = Grade(course_id=a.course_id, student_id=user.id, assignment_id=a.id, score=min(score, total), total=total, details_json=json.dumps(details))
    session.add(sub); session.add(g); session.commit(); session.refresh(sub); session.refresh(g)
    sub.ai_feedback_json = json.dumps({"score": g.score, "details": details, "advice": "根据失分点复习讲义对应章节，完成 3 道巩固题。"})
    sub.status = "GRADED"
    session.add(sub); session.commit()
    return {"submission_id": sub.id, "grade": {"score": g.score, "total": g.total, "details": details}}

@router.get("/grades/my")
def my_grades(session: Session = Depends(get_session), user=Depends(get_current_user)):
    rows = session.exec(select(Grade).where(Grade.student_id==user.id)).all()
    return rows
