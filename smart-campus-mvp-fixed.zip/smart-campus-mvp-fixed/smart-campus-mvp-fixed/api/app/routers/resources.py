import os, shutil, time
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlmodel import Session, select
from ..db import get_session
from ..auth import get_current_user
from ..models import Resource, Course

UPLOAD_DIR = "data/uploads"

router = APIRouter()

@router.post("/upload")
def upload_resource(course_id: int = Form(...), title: str = Form(...), type: str = Form("FILE"),
                    f: UploadFile = File(...),
                    session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role != "TEACHER":
        raise HTTPException(403, "Only teacher")
    if not session.get(Course, course_id):
        raise HTTPException(404, "Course not found")
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    fname = f"{int(time.time()*1000)}_{f.filename}"
    path = os.path.join(UPLOAD_DIR, fname)
    with open(path, "wb") as out:
        shutil.copyfileobj(f.file, out)
    r = Resource(course_id=course_id, title=title, type=type, file_path=path, size=os.path.getsize(path), uploader_id=user.id)
    session.add(r); session.commit(); session.refresh(r)
    return {"id": r.id, "title": r.title, "url": f"/uploads/{fname}"}

@router.get("/list")
def list_resources(course_id: int, session: Session = Depends(get_session), user=Depends(get_current_user)):
    rows = session.exec(select(Resource).where(Resource.course_id==course_id)).all()
    return rows
