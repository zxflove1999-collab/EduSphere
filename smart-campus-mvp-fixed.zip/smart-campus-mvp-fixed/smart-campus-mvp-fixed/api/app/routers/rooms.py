from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Form
from sqlmodel import Session, select
from ..db import get_session
from ..auth import get_current_user
from ..models import Room, RoomBooking

router = APIRouter()

@router.get("/free")
def free_rooms(start_at: str, end_at: str, session: Session = Depends(get_session), user=Depends(get_current_user)):
    start = datetime.fromisoformat(start_at); end = datetime.fromisoformat(end_at)
    rooms = session.exec(select(Room)).all()
    bookings = session.exec(select(RoomBooking)).all()
    busy = set()
    for b in bookings:
        if not (end <= b.start_at or start >= b.end_at):
            busy.add(b.room_id)
    return [r for r in rooms if r.id not in busy]

@router.post("/book")
def book_room(room_id: int = Form(...), start_at: str = Form(...), end_at: str = Form(...),
              session: Session = Depends(get_session), user=Depends(get_current_user)):
    start = datetime.fromisoformat(start_at); end = datetime.fromisoformat(end_at)
    for b in session.exec(select(RoomBooking).where(RoomBooking.room_id==room_id)).all():
        if not (end <= b.start_at or start >= b.end_at):
            raise HTTPException(400, "Room is busy in this time")
    rb = RoomBooking(room_id=room_id, user_id=user.id, start_at=start, end_at=end, status="CONFIRMED")
    session.add(rb); session.commit(); session.refresh(rb)
    return {"ok": True, "booking_id": rb.id}
