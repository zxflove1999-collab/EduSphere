from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Form, UploadFile, File
from sqlmodel import Session, select
from ..db import get_session
from ..auth import get_current_user
from ..models import Attendance, AttendanceLog, Course
from ..utils import haversine

router = APIRouter()

@router.post("")
def create_attendance(course_id: int = Form(...),
                      start_at: str = Form(...),
                      end_at: str = Form(...),
                      lat: float = Form(...),
                      lng: float = Form(...),
                      radius_m: int = Form(80),
                      face_threshold: float = Form(0.35),
                      session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role != "TEACHER":
        raise HTTPException(403, "Only teacher")
    if not session.get(Course, course_id):
        raise HTTPException(404, "Course not found")
    a = Attendance(course_id=course_id, start_at=datetime.fromisoformat(start_at),
                   end_at=datetime.fromisoformat(end_at), lat=lat, lng=lng,
                   radius_m=radius_m, face_threshold=face_threshold)
    session.add(a); session.commit(); session.refresh(a)
    return a

@router.post("/{attendance_id}/sign")
def sign(attendance_id: int,
         lat: float = Form(...), lng: float = Form(...),
         face_image: UploadFile = File(None),
         session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role != "STUDENT": raise HTTPException(403, "Only student")
    a = session.get(Attendance, attendance_id)
    if not a: raise HTTPException(404, "Attendance not found")
    now = datetime.utcnow()
    if now > a.end_at: raise HTTPException(400, "Too late")
    distance = haversine(lat, lng, a.lat, a.lng)
    if distance > a.radius_m:
        status = "OUT_OF_RANGE"; face_score = 0.0
    else:
        status = "ON_TIME" if now <= a.start_at else "LATE"
        face_score = 1.0  # demo pass
    log = AttendanceLog(attendance_id=attendance_id, student_id=user.id, face_score=face_score,
                        lat=lat, lng=lng, status=status)
    session.add(log); session.commit(); session.refresh(log)
    return {"ok": True, "status": status, "distance_m": round(distance,2), "face_score": face_score}

@router.get("/my")
def my_attendance(session: Session = Depends(get_session), user=Depends(get_current_user)):
    rows = session.exec(select(AttendanceLog).where(AttendanceLog.student_id==user.id)).all()
    return rows
