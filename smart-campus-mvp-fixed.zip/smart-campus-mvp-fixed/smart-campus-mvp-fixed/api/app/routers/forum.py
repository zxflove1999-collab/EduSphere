from fastapi import APIRouter, Depends, HTTPException, Form
from sqlmodel import Session, select
from ..db import get_session
from ..auth import get_current_user
from ..models import ForumPost, ForumComment

router = APIRouter()

@router.post("/posts")
def create_post(title: str = Form(...), content: str = Form(...),
                session: Session = Depends(get_session), user=Depends(get_current_user)):
    p = ForumPost(user_id=user.id, title=title, content=content)
    session.add(p); session.commit(); session.refresh(p)
    return {"id": p.id}

@router.get("/posts")
def list_posts(session: Session = Depends(get_session), user=Depends(get_current_user)):
    posts = session.exec(select(ForumPost).order_by(ForumPost.id.desc())).all()
    return posts

@router.post("/posts/{post_id}/comments")
def comment(post_id: int, content: str = Form(...), session: Session = Depends(get_session), user=Depends(get_current_user)):
    c = ForumComment(post_id=post_id, user_id=user.id, content=content)
    session.add(c); session.commit(); session.refresh(c)
    return {"id": c.id}

@router.get("/posts/{post_id}/comments")
def list_comments(post_id: int, session: Session = Depends(get_session), user=Depends(get_current_user)):
    return session.exec(select(ForumComment).where(ForumComment.post_id==post_id).order_by(ForumComment.id.asc())).all()
