from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Form
from sqlmodel import Session, select
from ..db import get_session
from ..auth import get_current_user
from ..models import Book, Loan, BookReview, BookTagAgg
from ..utils import aggregate_tags

router = APIRouter()

@router.get("/books")
def list_books(session: Session = Depends(get_session), user=Depends(get_current_user)):
    books = session.exec(select(Book)).all()
    res = []
    for b in books:
        aggs = session.exec(select(BookTagAgg).where(BookTagAgg.book_id==b.id)).all()
        tags = {a.tag: a.weight for a in aggs}
        res.append({"id": b.id, "isbn": b.isbn, "title": b.title, "author": b.author,
                    "copies_total": b.copies_total, "copies_available": b.copies_available, "tagAgg": tags})
    return res

@router.post("/borrow")
def borrow(book_id: int = Form(...), session: Session = Depends(get_session), user=Depends(get_current_user)):
    b = session.get(Book, book_id)
    if not b: raise HTTPException(404, "Book not found")
    if b.copies_available <= 0: raise HTTPException(400, "No copies available")
    b.copies_available -= 1
    loan = Loan(book_id=book_id, user_id=user.id, due_at=datetime.utcnow()+timedelta(days=14))
    session.add(loan); session.add(b); session.commit(); session.refresh(loan)
    return {"ok": True, "loan_id": loan.id, "due_at": loan.due_at}

@router.post("/return")
def return_book(loan_id: int = Form(...), rating: int = Form(...), text: str = Form(...),
                session: Session = Depends(get_session), user=Depends(get_current_user)):
    loan = session.get(Loan, loan_id)
    if not loan or loan.user_id != user.id: raise HTTPException(404, "Loan not found")
    if loan.returned_at: raise HTTPException(400, "Already returned")
    book = session.get(Book, loan.book_id)
    loan.returned_at = datetime.utcnow()
    book.copies_available += 1
    review = BookReview(book_id=book.id, user_id=user.id, rating=rating, text=text)
    session.add(review); session.add(loan); session.add(book); session.commit()
    reviews = session.exec(select(BookReview).where(BookReview.book_id==book.id)).all()
    tag_cnt = aggregate_tags([r.text for r in reviews])
    olds = session.exec(select(BookTagAgg).where(BookTagAgg.book_id==book.id)).all()
    for o in olds: session.delete(o)
    for tag, w in tag_cnt.items():
        session.add(BookTagAgg(book_id=book.id, tag=tag, weight=w))
    session.commit()
    return {"ok": True}
