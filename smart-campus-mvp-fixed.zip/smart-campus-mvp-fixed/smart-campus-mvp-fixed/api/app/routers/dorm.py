from fastapi import APIRouter, Depends, HTTPException, Form
from sqlmodel import Session, select
from ..db import get_session
from ..auth import get_current_user
from ..models import DormPreference, DormRoom, DormAssignment

router = APIRouter()

@router.post("/preferences")
def set_pref(sleep: int = Form(1), clean: int = Form(1), noise: int = Form(1),
             session: Session = Depends(get_session), user=Depends(get_current_user)):
    pref = session.exec(select(DormPreference).where(DormPreference.user_id==user.id)).first()
    if not pref:
        pref = DormPreference(user_id=user.id, sleep=sleep, clean=clean, noise=noise)
        session.add(pref)
    else:
        pref.sleep, pref.clean, pref.noise = sleep, clean, noise
        session.add(pref)
    session.commit()
    return {"ok": True}

@router.post("/assign")
def run_assign(session: Session = Depends(get_session), user=Depends(get_current_user)):
    prefs = session.exec(select(DormPreference)).all()
    rooms = session.exec(select(DormRoom)).all()
    prefs.sort(key=lambda p: (p.sleep, p.clean, p.noise))
    assignments = []
    ri = 0
    if not rooms:
        return {"ok": False, "msg":"no rooms"}
    cap_left = rooms[ri].capacity
    for p in prefs:
        if cap_left <= 0:
            ri += 1
            if ri >= len(rooms): break
            cap_left = rooms[ri].capacity
        assignments.append(DormAssignment(room_id=rooms[ri].id, user_id=p.user_id))
        cap_left -= 1
    olds = session.exec(select(DormAssignment)).all()
    for o in olds: session.delete(o)
    for a in assignments: session.add(a)
    session.commit()
    return {"ok": True, "assigned": len(assignments)}

@router.get("/me")
def my_dorm(session: Session = Depends(get_session), user=Depends(get_current_user)):
    from ..models import DormAssignment, DormRoom
    a = session.exec(select(DormAssignment).where(DormAssignment.user_id==user.id)).first()
    if not a: return {"room": None}
    room = session.get(DormRoom, a.room_id)
    return {"building": room.building, "room_no": room.room_no}
