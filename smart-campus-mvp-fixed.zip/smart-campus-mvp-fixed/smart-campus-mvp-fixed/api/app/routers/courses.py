import json
from fastapi import APIRouter, Depends, HTTPException, Form
from sqlmodel import Session, select
from ..db import get_session
from ..auth import get_current_user
from ..models import Course, Enrollment

router = APIRouter()

@router.post("")
def create_course(name: str = Form(...), code: str = Form(...), term: str = Form("2025 Spring"),
                  schedule_json: str = Form("{}"), capacity: int = Form(100),
                  session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role not in ("TEACHER", "ADMIN"):
        raise HTTPException(403, "Only teacher can create course")
    if session.exec(select(Course).where(Course.code==code)).first():
        raise HTTPException(400, "Course code exists")
    c = Course(name=name, code=code, teacher_id=user.id, term=term, schedule_json=schedule_json, capacity=capacity)
    session.add(c); session.commit(); session.refresh(c)
    return c

@router.post("/{course_id}/join")
def join_course(course_id: int, session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role != "STUDENT":
        raise HTTPException(403, "Only student can join")
    if not session.get(Course, course_id):
        raise HTTPException(404, "Course not found")
    if session.exec(select(Enrollment).where(Enrollment.course_id==course_id, Enrollment.student_id==user.id)).first():
        return {"ok": True}
    e = Enrollment(course_id=course_id, student_id=user.id)
    session.add(e); session.commit(); session.refresh(e)
    return {"ok": True}

@router.get("/my")
def my_courses(session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role == "TEACHER":
        return session.exec(select(Course).where(Course.teacher_id==user.id)).all()
    else:
        joins = session.exec(select(Enrollment).where(Enrollment.student_id==user.id)).all()
        ids = [j.course_id for j in joins]
        if not ids:
            return []
        return session.exec(select(Course).where(Course.id.in_(ids))).all()

@router.get("/timetable/my")
def my_timetable(session: Session = Depends(get_session), user=Depends(get_current_user)):
    if user.role == "TEACHER":
        courses = session.exec(select(Course).where(Course.teacher_id==user.id)).all()
    else:
        joins = session.exec(select(Enrollment).where(Enrollment.student_id==user.id)).all()
        ids = [j.course_id for j in joins]
        courses = session.exec(select(Course).where(Course.id.in_(ids))).all() if ids else []
    items = []
    for c in courses:
        try:
            sched = json.loads(c.schedule_json or "[]")
        except Exception:
            sched = []
        for s in sched:
            items.append({"course": c.name, "day": s.get("day"), "start": s.get("start"), "end": s.get("end"), "room": s.get("room")})
    return items
