from fastapi import APIRouter, Depends, HTTPException, Form
from sqlmodel import Session, select
from ..db import get_session
from ..models import User
from ..auth import hash_password, verify_password, create_access_token

router = APIRouter()

@router.post("/register")
def register(name: str = Form(...), email: str = Form(...), password: str = Form(...), role: str = Form("STUDENT"),
             session: Session = Depends(get_session)):
    if session.exec(select(User).where(User.email==email)).first():
        raise HTTPException(400, "Email already exists")
    u = User(name=name, email=email, role=role, password_hash=hash_password(password))
    session.add(u); session.commit(); session.refresh(u)
    return {"id": u.id, "email": u.email}

@router.post("/login")
def login(username: str = Form(...), password: str = Form(...), session: Session = Depends(get_session)):
    user = session.exec(select(User).where(User.email==username)).first()
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(401, "Invalid credentials")
    token = create_access_token({"sub": str(user.id), "role": user.role})
    return {"access_token": token, "token_type": "bearer", "user": {"id": user.id, "name": user.name, "role": user.role}}
