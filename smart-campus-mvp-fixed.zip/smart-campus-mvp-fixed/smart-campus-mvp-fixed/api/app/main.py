from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlmodel import Session, select
from .db import create_db_and_tables, engine
from .models import User, Room, Book, DormRoom
from .auth import hash_password
from .settings import settings
from .routers import auth, users, courses, assignments, resources, attendance, rooms, library, dorm, forum
import os

app = FastAPI(title="Smart Campus MVP", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs("data/uploads", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="data/uploads"), name="uploads")

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(users.router, prefix="/users", tags=["users"])
app.include_router(courses.router, prefix="/courses", tags=["courses"])
app.include_router(assignments.router, prefix="/assignments", tags=["assignments"])
app.include_router(resources.router, prefix="/resources", tags=["resources"])
app.include_router(attendance.router, prefix="/attendance", tags=["attendance"])
app.include_router(rooms.router, prefix="/rooms", tags=["rooms"])
app.include_router(library.router, prefix="/library", tags=["library"])
app.include_router(dorm.router, prefix="/dorm", tags=["dorm"])
app.include_router(forum.router, prefix="/forum", tags=["forum"])

@app.on_event("startup")
def on_startup():
    create_db_and_tables()
    with Session(engine) as s:
        if not s.exec(select(User).where(User.email==settings.admin_teacher_email)).first():
            s.add(User(name="Teacher One", email=settings.admin_teacher_email, role="TEACHER",
                       password_hash=hash_password(settings.admin_teacher_password)))
        if not s.exec(select(User).where(User.email==settings.demo_student_email)).first():
            s.add(User(name="Student One", email=settings.demo_student_email, role="STUDENT",
                       password_hash=hash_password(settings.demo_student_password)))
        if not s.exec(select(Room)).first():
            s.add_all([Room(building="A", room_no="101", capacity=60),
                       Room(building="A", room_no="102", capacity=60),
                       Room(building="B", room_no="201", capacity=30)])
        if not s.exec(select(Book)).first():
            s.add_all([Book(isbn="9787111123456", title="数据结构入门", author="张三", copies_total=3, copies_available=3),
                       Book(isbn="9787111123457", title="Python 实践", author="李四", copies_total=2, copies_available=2)])
        if not s.exec(select(DormRoom)).first():
            s.add_all([DormRoom(building="D1", room_no="101", capacity=4),
                       DormRoom(building="D1", room_no="102", capacity=4)])
        s.commit()

@app.get("/health")
def health():
    return {"ok": True}
