const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
export function setToken(t){ localStorage.setItem('token', t) }
export function getToken(){ return localStorage.getItem('token') }
export async function apiFetch(path, opts={}){
  const headers = opts.headers || {}
  const token = getToken()
  if(!(opts.body instanceof FormData)){
    headers['Content-Type'] = 'application/json'
  }
  if(token) headers['Authorization'] = 'Bearer ' + token
  const res = await fetch(API + path, { ...opts, headers })
  if(!res.ok){
    const msg = await res.text()
    throw new Error(msg || res.statusText)
  }
  const ct = res.headers.get('content-type') || ''
  if(ct.includes('application/json')) return await res.json()
  return await res.text()
}
