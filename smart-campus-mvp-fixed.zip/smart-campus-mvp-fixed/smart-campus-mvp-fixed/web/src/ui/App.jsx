import React, { useEffect, useState } from 'react'
import { apiFetch, setToken, getToken } from '../api'

function Login({onOk}){
  const [username, setU] = useState('t1@example.com')
  const [password, setP] = useState('123456')
  const [msg, setMsg] = useState('')
  async function doLogin(e){
    e.preventDefault()
    const form = new FormData()
    form.append('username', username)
    form.append('password', password)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000') + '/auth/login', { method:'POST', body: form })
    const j = await r.json()
    if(!r.ok){ setMsg(j.detail || '登录失败'); return }
    setToken(j.access_token); onOk(j.user)
  }
  return (<div>
    <h2>登录</h2>
    <form onSubmit={doLogin}>
      <input value={username} onChange={e=>setU(e.target.value)} placeholder="邮箱" /> <br/>
      <input type="password" value={password} onChange={e=>setP(e.target.value)} placeholder="密码" /> <br/>
      <button>登录</button>
    </form>
    <div style={{color:'red'}}>{msg}</div>
    <p>示例教师: t1@example.com / 123456；学生: s1@example.com / 123456</p>
  </div>)
}

function Nav({page, setPage, user}){
  const tabs = ['dashboard','courses','assign','resources','attendance','rooms','library','dorm','forum']
  return (<div style={{display:'flex', gap:10, flexWrap:'wrap'}}>
    {tabs.map(t => <button key={t} onClick={()=>setPage(t)} disabled={page===t}>{t}</button>)}
    <span style={{marginLeft:20}}>当前用户：{user?.name}（{user?.role}）</span>
  </div>)
}

function Courses({user}){
  const [list, setList] = useState([])
  const [name, setName] = useState('高等数学')
  const [code, setCode] = useState('MATH101')
  const [cid, setCid] = useState('')
  async function load(){ setList(await apiFetch('/courses/my')) }
  useEffect(()=>{ load() },[])
  async function create(){
    const fd = new FormData()
    fd.append('name', name); fd.append('code', code); fd.append('term','2025 Spring'); 
    fd.append('schedule_json', JSON.stringify([{day:1,start:'08:00',end:'09:40',room:'A-101'}]))
    await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/courses', {method:'POST', body: fd, headers:{Authorization:'Bearer '+getToken()}})
    await load()
  }
  async function join(){
    await apiFetch('/courses/'+cid+'/join', {method:'POST'}); await load()
  }
  async function timetable(){
    const t = await apiFetch('/courses/timetable/my'); alert(JSON.stringify(t,null,2))
  }
  return (<div>
    <h3>我的课程</h3>
    <button onClick={load}>刷新</button> <button onClick={timetable}>查看课表</button>
    <ul>{list.map(c=> <li key={c.id}>{c.name} ({c.code})</li>)}</ul>
    {user.role==='TEACHER' && <div>
      <h4>创建课程</h4>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="课程名" />
      <input value={code} onChange={e=>setCode(e.target.value)} placeholder="课程代码" />
      <button onClick={create}>创建</button>
    </div>}
    {user.role==='STUDENT' && <div>
      <h4>加入课程</h4>
      <input value={cid} onChange={e=>setCid(e.target.value)} placeholder="课程ID" />
      <button onClick={join}>加入</button>
    </div>}
  </div>)
}

function Assign({user}){
  const [courseId, setCourseId] = useState('1')
  const [title, setTitle] = useState('作业1')
  const [rubric, setRubric] = useState('[{"key":"勾股定理","weight":50,"match":["勾股","a^2+b^2=c^2"]},{"key":"直角三角形","weight":50,"match":["直角","三角形"]}]')
  const [assignmentId, setAid] = useState('1')
  const [text, setText] = useState('这是我的答案，包含勾股和直角三角形')
  async function create(){
    const fd = new FormData(); fd.append('course_id', courseId); fd.append('title', title);
    fd.append('rubric_json', rubric); fd.append('type','SUBJ')
    await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/assignments', {method:'POST', body: fd, headers:{Authorization:'Bearer '+getToken()}})
    alert('已创建，记下返回的ID（见后端日志或数据库）')
  }
  async function submit(){
    const fd = new FormData(); fd.append('text_content', text)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/assignments/'+assignmentId+'/submit', {method:'POST', body: fd, headers:{Authorization:'Bearer '+getToken()}})
    alert(await r.text())
  }
  async function myGrades(){
    const g = await apiFetch('/assignments/grades/my'); alert(JSON.stringify(g,null,2))
  }
  return (<div>
    {user.role==='TEACHER' && <div>
      <h3>发布作业</h3>
      <input value={courseId} onChange={e=>setCourseId(e.target.value)} placeholder="课程ID" />
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="标题" />
      <textarea value={rubric} onChange={e=>setRubric(e.target.value)} rows="5" cols="60"></textarea><br/>
      <button onClick={create}>创建作业</button>
    </div>}
    {user.role==='STUDENT' && <div>
      <h3>提交作业</h3>
      <input value={assignmentId} onChange={e=>setAid(e.target.value)} placeholder="作业ID" />
      <textarea value={text} onChange={e=>setText(e.target.value)} rows="3" cols="60"></textarea><br/>
      <button onClick={submit}>提交并AI评分</button>
      <button onClick={myGrades}>查看成绩</button>
    </div>}
  </div>)
}

function Resources({user}){
  const [courseId, setCourseId] = useState('1')
  const [title, setTitle] = useState('第一章PPT')
  const [file, setFile] = useState(null)
  const [list, setList] = useState([])
  async function upload(){
    const fd = new FormData()
    fd.append('course_id', courseId); fd.append('title', title); fd.append('type','FILE'); fd.append('f', file)
    const res = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/resources/upload',{method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    alert(await res.text())
  }
  async function load(){
    const l = await apiFetch('/resources/list?course_id='+courseId); setList(l)
  }
  return (<div>
    <h3>课程资源</h3>
    {user.role==='TEACHER' && <div>
      <input value={courseId} onChange={e=>setCourseId(e.target.value)} placeholder="课程ID" />
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="标题" />
      <input type="file" onChange={e=>setFile(e.target.files[0])} />
      <button onClick={upload}>上传</button>
    </div>}
    <div>
      <input value={courseId} onChange={e=>setCourseId(e.target.value)} placeholder="课程ID" />
      <button onClick={load}>查看列表</button>
      <ul>{list.map(r => <li key={r.id}><a href={(import.meta.env.VITE_API_URL || 'http://localhost:8000') + r.file_path.replace('data/uploads','/uploads')} target="_blank">{r.title}</a></li>)}</ul>
    </div>
  </div>)
}

function Attendance({user}){
  const [courseId, setCourseId] = useState('1')
  const [lat, setLat] = useState('31.2304')
  const [lng, setLng] = useState('121.4737')
  const [startAt, setStartAt] = useState(new Date().toISOString())
  const [endAt, setEndAt] = useState(new Date(Date.now()+60*60*1000).toISOString())
  const [attId, setAttId] = useState('1')
  const [status, setStatus] = useState('')

  function getLoc(){
    if(navigator.geolocation){
      navigator.geolocation.getCurrentPosition(pos=>{
        setLat(pos.coords.latitude.toString())
        setLng(pos.coords.longitude.toString())
      })
    } else alert('浏览器不支持定位')
  }

  async function create(){
    const fd = new FormData()
    fd.append('course_id', courseId); fd.append('start_at', startAt); fd.append('end_at', endAt)
    fd.append('lat', lat); fd.append('lng', lng); fd.append('radius_m', '80')
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/attendance', {method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    setStatus(await r.text())
  }

  async function sign(e){
    e.preventDefault()
    const fd = new FormData()
    fd.append('lat', lat); fd.append('lng', lng)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/attendance/'+attId+'/sign', {method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    setStatus(await r.text())
  }

  return (<div>
    <h3>考勤</h3>
    <button onClick={getLoc}>获取当前位置</button> 纬度:<input value={lat} onChange={e=>setLat(e.target.value)}/> 经度:<input value={lng} onChange={e=>setLng(e.target.value)}/>
    {user.role==='TEACHER' && <div>
      <h4>创建签到</h4>
      课程ID:<input value={courseId} onChange={e=>setCourseId(e.target.value)}/> 开始:<input value={startAt} onChange={e=>setStartAt(e.target.value)} size="30"/> 结束:<input value={endAt} onChange={e=>setEndAt(e.target.value)} size="30"/>
      <button onClick={create}>创建</button>
    </div>}
    {user.role==='STUDENT' && <div>
      <h4>学生签到</h4>
      签到ID:<input value={attId} onChange={e=>setAttId(e.target.value)}/>
      <button onClick={sign}>签到</button>
    </div>}
    <pre>{status}</pre>
  </div>)
}

function Rooms(){
  const [startAt, setStartAt] = useState(new Date().toISOString())
  const [endAt, setEndAt] = useState(new Date(Date.now()+2*60*60*1000).toISOString())
  const [free, setFree] = useState([])
  const [roomId, setRoomId] = useState('1')
  async function check(){
    const r = await apiFetch('/rooms/free?start_at='+encodeURIComponent(startAt)+'&end_at='+encodeURIComponent(endAt))
    setFree(r)
  }
  async function book(){
    const fd = new FormData()
    fd.append('room_id', roomId); fd.append('start_at', startAt); fd.append('end_at', endAt)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/rooms/book',{method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    alert(await r.text())
  }
  return (<div>
    <h3>空闲教室</h3>
    <div>开始:<input value={startAt} onChange={e=>setStartAt(e.target.value)} size="30"/> 结束:<input value={endAt} onChange={e=>setEndAt(e.target.value)} size="30"/> <button onClick={check}>查询</button></div>
    <ul>{free.map(r=> <li key={r.id}>{r.building}-{r.room_no} 容量{r.capacity}</li>)}</ul>
    <div>房间ID:<input value={roomId} onChange={e=>setRoomId(e.target.value)}/> <button onClick={book}>预约</button></div>
  </div>)
}

function Library(){
  const [books, setBooks] = useState([])
  const [borrowId, setBorrowId] = useState('')
  const [loanId, setLoanId] = useState('')
  const [rating, setRating] = useState('5')
  const [text, setText] = useState('非常推荐')
  async function load(){ setBooks(await apiFetch('/library/books')) }
  async function borrow(){
    const fd = new FormData(); fd.append('book_id', borrowId)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/library/borrow',{method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    alert(await r.text())
  }
  async function ret(){
    const fd = new FormData(); fd.append('loan_id', loanId); fd.append('rating', rating); fd.append('text', text)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/library/return',{method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    alert(await r.text())
  }
  return (<div>
    <h3>图书借阅</h3>
    <button onClick={load}>加载图书</button>
    <ul>{books.map(b=> <li key={b.id}>[{b.id}] {b.title} by {b.author} - 库存{b.copies_available}/{b.copies_total} 标签:{Object.entries(b.tagAgg||{}).map(([k,v])=>k+':'+v).join(', ')}</li>)}</ul>
    <div>借书：图书ID <input value={borrowId} onChange={e=>setBorrowId(e.target.value)}/> <button onClick={borrow}>借阅</button></div>
    <div>还书：借阅ID <input value={loanId} onChange={e=>setLoanId(e.target.value)}/> 评分<input value={rating} onChange={e=>setRating(e.target.value)}/> 评价<input value={text} onChange={e=>setText(e.target.value)}/> <button onClick={ret}>归还并评价</button></div>
  </div>)
}

function Dorm(){
  const [sleep, setSleep] = useState('1')
  const [clean, setClean] = useState('1')
  const [noise, setNoise] = useState('1')
  const [msg, setMsg] = useState('')
  const [mine, setMine] = useState('')
  async function save(){
    const fd = new FormData(); fd.append('sleep', sleep); fd.append('clean', clean); fd.append('noise', noise)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/dorm/preferences',{method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    setMsg(await r.text())
  }
  async function assign(){
    const r = await apiFetch('/dorm/assign',{method:'POST'}); setMsg(JSON.stringify(r))
  }
  async function me(){
    const r = await apiFetch('/dorm/me'); setMine(JSON.stringify(r))
  }
  return (<div>
    <h3>宿舍分配</h3>
    偏好：作息(0早 1中 2晚) <input value={sleep} onChange={e=>setSleep(e.target.value)}/> 
    整洁(0低 1中 2高) <input value={clean} onChange={e=>setClean(e.target.value)}/> 
    噪音(0低 1中 2高) <input value={noise} onChange={e=>setNoise(e.target.value)}/> 
    <button onClick={save}>保存</button> <button onClick={assign}>一键分配</button> <button onClick={me}>我的宿舍</button>
    <pre>{msg}</pre>
    <pre>{mine}</pre>
  </div>)
}

function Forum(){
  const [title, setTitle] = useState('大家好')
  const [content, setContent] = useState('第一条帖子')
  const [posts, setPosts] = useState([])
  const [pid, setPid] = useState('')
  const [comment, setComment] = useState('不错')
  async function create(){
    const fd = new FormData(); fd.append('title', title); fd.append('content', content)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/forum/posts',{method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    alert(await r.text())
  }
  async function load(){
    setPosts(await apiFetch('/forum/posts'))
  }
  async function addComment(){
    const fd = new FormData(); fd.append('content', comment)
    const r = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:8000')+'/forum/posts/'+pid+'/comments',{method:'POST', headers:{Authorization:'Bearer '+getToken()}, body: fd})
    alert(await r.text())
  }
  return (<div>
    <h3>论坛</h3>
    <div><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="标题"/> <input value={content} onChange={e=>setContent(e.target.value)} placeholder="内容"/> <button onClick={create}>发帖</button></div>
    <button onClick={load}>刷新帖子</button>
    <ul>{posts.map(p=> <li key={p.id}>[{p.id}] {p.title} - {p.content}</li>)}</ul>
    <div>评论 帖子ID<input value={pid} onChange={e=>setPid(e.target.value)}/> 内容<input value={comment} onChange={e=>setComment(e.target.value)}/> <button onClick={addComment}>评论</button></div>
  </div>)
}

export default function App(){
  const [user, setUser] = useState(null)
  const [page, setPage] = useState('dashboard')

  useEffect(()=>{
    if(getToken()){
      apiFetch('/users/me').then(u=> setUser(u)).catch(()=>{})
    }
  },[])

  if(!user) return <Login onOk={setUser} />

  return (<div style={{padding:20}}>
    <h1>智能校园系统 - MVP</h1>
    <Nav page={page} setPage={setPage} user={user} />
    <hr/>
    {page==='dashboard' && <div><p>请选择上方模块开始体验。</p></div>}
    {page==='courses' && <Courses user={user} />}
    {page==='assign' && <Assign user={user} />}
    {page==='resources' && <Resources user={user} />}
    {page==='attendance' && <Attendance user={user} />}
    {page==='rooms' && <Rooms />}
    {page==='library' && <Library />}
    {page==='dorm' && <Dorm />}
    {page==='forum' && <Forum />}
  </div>)
}
