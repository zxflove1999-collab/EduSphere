# 智能校园系统 - 最小可运行版 (MVP, Fixed)

这是一份已修复依赖/卷挂载问题的版本：
- 去掉 docker-compose 的 `version` 警告；
- 将 `/app/data` 改为 **named volume**，避免 Windows 路径权限导致 SQLite 启动失败；
- 升级 `sqlmodel` 到 v2 兼容版本；移除无用的 `Relationship` 导入。

## 一键启动
```bash
docker compose up --build
```
前端：<http://localhost:5173>  
后端文档：<http://localhost:8000/docs>

## 账号
- 教师：`t1@example.com` / `123456`
- 学生：`s1@example.com` / `123456`
